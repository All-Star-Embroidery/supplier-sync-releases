All Star Bulk Order Block v1.1.1

GitHub-managed production release for All Star Embroidery.

Highlights:
- Gutenberg bulk-order block with editable workflow content and styles.
- Supplier Sync compatible with SanMar, S&S Activewear, Momentec, and multi-supplier Woo variations.
- Server-side variation refresh/validation before cart submission.
- Atomic cart rollback if any selected variation fails.
- Detailed cart failure messages instead of generic HTTP 500 responses.
- Allows validated ASBO variations through WooCommerce even during a temporary blank base-price state because ASBO supplies the decorated selling price.
- GitHub manifest updater with automatic WordPress plugin updates.
- Post-checkout artwork workflow remains separate and supported.

Release source:
https://github.com/rolejarczyk/ASE.SupplierSync-Releases/tree/main/asbo


v1.1.1 mobile UX improvements:
- Hides the redundant large expanded-product hero image on screens 767px and below.
- Keeps one product accordion open at a time on mobile to reduce long-page drift.
- Fits the full per-piece pricing matrix inside the mobile viewport without horizontal swiping.
- Tightens mobile spacing, typography, tier messaging, and decoration controls while preserving desktop styling.
